from .main import Another_Plugin

__all__ = ["Another_Plugin"]