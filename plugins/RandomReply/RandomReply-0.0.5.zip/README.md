# 介绍

一个参考 [nonebot_plugin_random_reply](https://github.com/Alpaca4610/nonebot_plugin_random_reply) 实现的 NcatBot 插件

## 使用说明

1. **安装插件**  
   请参考 [安装和使用插件](https://docs.ncatbot.xyz/guide/inplugin/)

2. **配置要求**  
   安装完成后，需要配置 `config.json` 文件才能使插件正常工作

   配置选项功能请参考main.py中的default_config部分
