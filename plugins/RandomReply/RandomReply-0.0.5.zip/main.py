import asyncio
import json
import logging
import os
import random
import re
from typing import List, Dict, Any

import httpx
from ncatbot.core.element import MessageChain, Text, At
from ncatbot.core.message import GroupMessage
from ncatbot.plugin import BasePlugin, CompatibleEnrollment

bot = CompatibleEnrollment


class RandomReply(BasePlugin):
    name = "RandomReply"
    version = "0.0.5"

    default_config = {
        "llm_api_url": "",
        "llm_api_key": "",
        "llm_model": "",
        "bot_name": "",
        "default_prompt": "【任务规则】1. 根据当前聊天记录的语境，回复最后1条内容进行回应; 2. 用贴吧老哥的风格的口语化短句回复，禁止使用超过30个字的长句; 3. 模仿真实网友的交流特点：适当使用缩写、流行梗、表情符号; 4. 输出必须为纯文本，禁止任何格式标记或前缀; 5. 当出现多个话题时，优先回应最新的发言内容",
        "reply_chance": 0.1,
        "max_retries": 3,
        "request_timeout": 12.0,
        "network_settings": {
            "max_connections": 100,
            "max_keepalive": 20,
            "retry_delay_base": 1.0
        },
        "advanced": {
            "enable_verbose_logging": False,
            "filter_keywords": [],
            "temperature": 0.7,
            "max_tokens": 100
        }
    }

    async def on_load(self):
        """初始化插件"""
        self.logger = logging.getLogger(f"ncatbot.plugin.{self.name}")

        self.config = self.load_config(self.default_config)
        self.llm_api_key = os.getenv('SILICONFLOW_API_KEY') or self.config.get('llm_api_key')

        if not self.llm_api_key:
            self.logger.error("API密钥未配置")
            raise ValueError("API密钥未配置")

        # 初始化HTTP客户端
        self.client = httpx.AsyncClient(
            timeout=self.config["request_timeout"],
            limits=httpx.Limits(
                max_connections=self.config["network_settings"]["max_connections"],
                max_keepalive_connections=self.config["network_settings"]["max_keepalive"]
            )
        )
        self.logger.info(f"{self.name} 插件初始化完成，版本 {self.version}")

    async def close(self):
        await self.client.aclose()
        self.logger.info(f"{self.name} 插件已关闭")

    def format_message_history(self, message_data: Dict) -> List[Dict]:
        try:
            if not message_data or 'data' not in message_data:
                return []

            return [
                {
                    "T": str(msg.get('time', '')),
                    "N": msg.get('sender', {}).get('nickname', ''),
                    "C": msg.get('raw_message', '')
                }
                for msg in message_data.get('data', {}).get('messages', [])
            ]

        except Exception as e:
            self.logger.error(f"格式化消息历史出错: {str(e)}")
            return []

    async def generate_llm_response(self, history: List[Dict]) -> str | None | Any:
        """调用 LLM 生成回复"""
        for attempt in range(self.config["max_retries"]):
            try:
                payload = {
                    "model": self.config['llm_model'],
                    "messages": [{
                        "role": "user",
                        "content": self.config['default_prompt'] + "\n" +
                                   "\n".join([f"{item['N']}: {item['C']}" for item in history])
                    }],
                    "max_tokens": self.config["advanced"]["max_tokens"]
                }

                response = await self.client.post(
                    self.config['llm_api_url'],
                    headers={"Authorization": f"Bearer {self.llm_api_key}"},
                    json=payload
                )
                response.raise_for_status()

                return response.json()['choices'][0]['message']['content'].strip()

            except Exception as e:
                self.logger.warning(f"尝试 {attempt + 1} 失败: {str(e)}")
                if attempt == self.config["max_retries"] - 1:
                    return "生成回复时出错，请稍后再试"
                await asyncio.sleep(self.config["network_settings"]["retry_delay_base"] * (attempt + 1))

    def is_at_me(self, msg: GroupMessage) -> bool:
        """检测是否 @ 了 bot"""
        try:
            if hasattr(msg, 'raw_message'):
                bot_qq = str(msg.self_id)  # 当前 bot QQ 号

                # 使用正则提取 @ 的 QQ 号
                match = re.search(r'\[CQ:at,qq=(\d+)]', msg.raw_message)

                if match:
                    at_qq = match.group(1)
                    return at_qq == bot_qq  # 判断是否 @ 的是 bot 本身

            return False

        except Exception as e:
            self.logger.error(f"检测 @ 出错: {str(e)}")
            return False

    @bot.group_event()
    async def get_group_msg_history(self, msg: GroupMessage):
        """处理群消息"""
        try:
            # 检测是否 @ bot
            at_me = self.is_at_me(msg)
            should_reply = at_me or (random.random() <= self.config["reply_chance"])

            if not should_reply:
                self.logger.info("未触发回复")
                return

            history = await self.api.get_group_msg_history(msg.group_id, 0, 20, False)
            formatted = self.format_message_history(history)

            if not formatted:
                return

            reply = await self.generate_llm_response(formatted[-5:])
            if not reply:
                return

            await self.api.post_group_msg(
                group_id=msg.group_id,
                rtf=MessageChain([Text(reply)])
            )

        except Exception as e:
            self.logger.error(f"处理群消息出错: {str(e)}")

    def load_config(self, default_config):
        try:
            with open('plugins/RandomReply/config.json', 'r', encoding='utf-8') as f:
                return {**default_config, **json.load(f)}
        except Exception as e:
            self.logger.warning(f"加载配置失败，使用默认配置: {str(e)}")
            return default_config


def setup(bot):
    try:
        plugin = RandomReply(bot)
        bot.add_cleanup_task(plugin.close)
        return plugin
    except Exception as e:
        logging.getLogger("ncatbot.plugin").error(f"初始化RandomReply失败: {str(e)}")
        raise
