import logging
from typing import Optional

from jmcomic import create_option_by_file
from ncatbot.core.message import GroupMessage
from ncatbot.plugin import BasePlugin, CompatibleEnrollment

bot = CompatibleEnrollment


async def get_comic(album_id: str) -> Optional[str]:
    """下载漫画

    Args:
        album_id: 漫画ID

    Returns:
        str: 成功返回文件路径，失败返回None
    """
    try:
        option = create_option_by_file('plugins/JmComic/config.yml')
        option.download_album(album_id)
        return f"comic/pdf/{album_id}.pdf"
    except FileNotFoundError:
        logging.error(f"配置文件未找到: plugins/JmComic/config.yml")
        return None
    except Exception as e:
        logging.error(f"下载漫画 {album_id} 失败: {str(e)}")
        return None


class JmComic(BasePlugin):
    name = "JmComic"
    version = "0.0.5"

    @bot.group_event()
    async def on_group_event(self, msg: GroupMessage):
        command_part = msg.raw_message.split()
        if command_part[0] == "/jm" and len(command_part) == 2:
            album_id = command_part[1]
            # 下载漫画
            file_path = await get_comic(album_id)
            if file_path:
                await self.api.post_group_file(msg.group_id, file=file_path)
            else:
                await self.api.post_group_msg(msg.group_id, f"下载漫画 {album_id} 失败，请检查ID是否正确或稍后再试")

    @bot.private_event()
    async def on_private_event(self, msg: GroupMessage):
        command_part = msg.raw_message.split()
        if command_part[0] == "jm" and len(command_part) == 2:
            album_id = command_part[1]
            # 下载漫画
            file_path = await get_comic(album_id)
            if file_path:
                await self.api.post_private_file(msg.user_id, file=file_path)
            else:
                await self.api.post_private_msg(msg.user_id, f"下载漫画 {album_id} 失败，请检查ID是否正确或稍后再试")
