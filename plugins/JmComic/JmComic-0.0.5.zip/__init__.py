from .main import JmComic

__all__ = ["JmComic"]
