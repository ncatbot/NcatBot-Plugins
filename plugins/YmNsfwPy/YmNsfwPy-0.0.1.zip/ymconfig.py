from typing import List, Dict, Any, Optional

class NSFWConfig:
    """NSFW检测配置类"""
    
    def __init__(self):
        self.data = {
            "global_config": {},
            "groups": {},
            "group_admins": {}
        }
        self._nsfwpy_type = None
        self._threshold = None

    def init_data(self, plugin_data: dict):
        if plugin_data is None:
            plugin_data = {}
        
        self.data = plugin_data
        
        # 确保基础数据结构存在
        if "global_config" not in self.data:
            self.data["global_config"] = {}
        if "groups" not in self.data:
            self.data["groups"] = {}
        if "group_admins" not in self.data:
            self.data["group_admins"] = {}
        
        self._nsfwpy_type = self.get_global_config('nsfwpy_type') or 'd'
        self._threshold = self.get_threshold()
    
    def get_global_config(self, key: str) -> Optional[str]:
        return self.data["global_config"].get(key)
            
    def set_global_config(self, key: str, value: str):
        self.data["global_config"][key] = value
    
    @property
    def nsfwpy_type(self) -> str:
        return self._nsfwpy_type
    
    @nsfwpy_type.setter
    def nsfwpy_type(self, value: str):
        self._nsfwpy_type = value
        self.set_global_config('nsfwpy_type', value)
    
    @property
    def threshold(self) -> float:
        return self._threshold
    
    @threshold.setter 
    def threshold(self, value: float):
        if 0 <= value <= 1:
            self._threshold = value
            self.set_threshold(value)
            
    def get_threshold(self) -> float:
        threshold = self.get_global_config('threshold')
        return float(threshold) if threshold else 0.85
        
    def set_threshold(self, value: float):
        self.set_global_config('threshold', str(value))
    
    def is_global_admin(self, user_id: int) -> bool:
        admin_ids = self.get_global_config('admin_users')
        return str(user_id) in admin_ids.split(',') if admin_ids else False
    
    def get_global_admins(self) -> List[int]:
        """获取全局管理员列表"""
        admin_ids = self.get_global_config('admin_users')
        return [int(x) for x in admin_ids.split(',') if x] if admin_ids else []
    
    def add_global_admin(self, admin_id: int) -> None:
        """添加全局管理员"""
        current_admins = self.get_global_admins()
        if admin_id not in current_admins:
            current_admins.append(admin_id)
            admin_str = ','.join(str(x) for x in current_admins)
            self.set_global_config('admin_users', admin_str)

    def remove_global_admin(self, admin_id: int) -> None:
        """移除全局管理员"""
        current_admins = self.get_global_admins()
        if admin_id in current_admins:
            current_admins.remove(admin_id)
            admin_str = ','.join(str(x) for x in current_admins)
            self.set_global_config('admin_users', admin_str)
    
    def get_group_settings(self, group_id: str) -> Optional[Dict[str, Any]]:
        str_group_id = str(group_id)
        return {
            'check': self.data["groups"].get(str_group_id, False),
            'admins': self.data["group_admins"].get(str_group_id, [])
        }
    
    def is_group_admin(self, group_id: int, user_id: int) -> bool:
        settings = self.get_group_settings(group_id)
        return settings and user_id in settings['admins']
    
    def is_group_check_enabled(self, group_id: int) -> bool:
        settings = self.get_group_settings(group_id)
        return settings and settings['check']
    
    def update_group_settings(self, group_id: int, admins: List[int], check: bool = True):
        str_group_id = str(group_id)
        self.data["groups"][str_group_id] = check
        if admins is not None:
            self.data["group_admins"][str_group_id] = admins
    
    def remove_group_settings(self, group_id: int):
        str_group_id = str(group_id)
        self.data["groups"].pop(str_group_id, None)
        self.data["group_admins"].pop(str_group_id, None)
    
    def get_group_admins(self, group_id: int) -> List[int]:
        settings = self.get_group_settings(group_id)
        return settings['admins'] if settings else []
    
    def add_group_admin(self, group_id: int, admin_id: int):
        str_group_id = str(group_id)
        if str_group_id not in self.data["group_admins"]:
            self.data["group_admins"][str_group_id] = []
        if admin_id not in self.data["group_admins"][str_group_id]:
            self.data["group_admins"][str_group_id].append(admin_id)

    def remove_group_admin(self, group_id: int, admin_id: int):
        str_group_id = str(group_id)
        if str_group_id in self.data["group_admins"]:
            if admin_id in self.data["group_admins"][str_group_id]:
                self.data["group_admins"][str_group_id].remove(admin_id)

    def get_monitor_groups(self) -> List[str]:
        return [group_id for group_id, enabled in self.data["groups"].items() if enabled]

NSFW_CONFIG = NSFWConfig()