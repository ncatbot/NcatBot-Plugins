from ncatbot.plugin import BasePlugin, CompatibleEnrollment
from ncatbot.core.message import GroupMessage
from ncatbot.utils import get_log

import os
import random
import re
import asyncio

LOG = get_log("Setu")

bot = CompatibleEnrollment  # 兼容回调函数注册器

class Setu(BasePlugin):
    name = "Setu" # 插件名称
    version = "0.0.2" # 插件版本
    dependencies = {
        # "access": ">=1.0.0"
    }

    # @bot.startup_event()
    # async def on_startup(self):
    #     await self._load_image()
        
    async def _load_image(self):
        path = self.config["path"]
        if os.path.exists(path):
            self.images = []
            for file in os.listdir(path):
                if os.path.isfile(os.path.join(path, file)):
                    self.images.append(os.path.join(path, file))
            LOG.info(f"加载 {len(self.images)} 张图片")
        else:
            LOG.warning(f"图片路径 {path} 不存在")
        return len(self.images)
    
    async def on_load(self):
        self.register_config("path", r"path/to/image")
        self.register_admin_func("load_image", self.load_image, permission_raise=True)
        self.register_admin_func("status", self.status, permission_raise=True)
        self.register_user_func(
            "/loli", 
            self.loli, 
            prefix="/loli", 
            description="发送随机色图",
            usage="/loli [数量] - 发送1-5张随机色图，默认为1张",
            examples=["/loli", "/loli 3", "/loli 5"]
        )
        self.images = []
        await self._load_image()
        print(f"{self.name} 插件已加载")
        print(f"插件版本: {self.version}")
    
    async def status(self, msg:GroupMessage):
        await msg.reply(f"当前图片: {len(self.images)} 张, 路径: {self.data['config']['path']}")
    
    async def loli(self, msg:GroupMessage):
        # 解析参数
        LOG.info(f"收到消息: {msg.raw_message}")
        count = 1  # 默认发送1张
        match = re.match(r"/loli\s*(\d+)", msg.raw_message)
        if match:
            try:
                count = int(match.group(1))
                # 限制数量在1-10之间
                count = max(1, min(10, count))
            except ValueError:
                count = 1
        
        # 如果没有足够的图片
        if len(self.images) < count:
            await msg.reply(f"图片数量不足，当前只有 {len(self.images)} 张图片")
            return
        
        # 随机选择指定数量的图片
        selected_images = random.sample(self.images, count)
        
        # 使用合并转发消息
        if count > 1:
            # 先发送给自己
            forward_messages = []
            
            # 并发发送所有图片
            tasks = [self.api.post_private_msg(msg.self_id, image=image) for image in selected_images]
            results = await asyncio.gather(*tasks)
            forward_messages = [result["data"]["message_id"] for result in results]
            # 串行版本
            # for image in selected_images:
            #     data = await self.api.post_private_msg(msg.self_id, image=image)
            #     forward_messages.append(data["data"]["message_id"])
            
            # 发送合并转发消息
            await self.api.send_group_forward_msg(
                group_id=msg.group_id,
                messages=forward_messages,
            )
        else:
            # 单张图片直接发送
            await self.api.post_group_msg(msg.group_id, image=selected_images[0])
    
    async def load_image(self, msg:GroupMessage):
        count = await self._load_image()
        await msg.reply(f"从 {self.config['path']} 加载 {count} 张图片")
            
        